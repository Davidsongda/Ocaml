(* This file contains a few helper functions and type declarations
   that are to be used in Homework 2. *)

(* Place part 1 functions 'take', 'drop', 'length', 'rev',
   'is_elem_by', 'is_elem', 'dedup', and 'split_by' here. *)

let length l = List.fold_left (fun n x -> n+1) 0 l
(* val length : 'a list -> int = <fun>  *)

let rev lst = List.fold_left (fun x xs -> xs::x) [] lst
(* val rev : 'a list -> 'a list = <fun> *)

let is_elem_by equals e lst = if (List.filter (fun x -> equals x e) lst) = [] then false
                              else true
(* val is_elem_by : ('a -> 'b -> bool) -> 'b -> 'a list -> bool = <fun> *)

let is_elem e lst = is_elem_by (fun x y -> x = y) e lst
(* val is_elem : 'a -> 'a list -> bool = <fun> *)

let dedup lst =
    List.fold_right (fun x l -> if(is_elem x l = true) then l
    else x::l)  lst []
(* val dedup : 'a list -> 'a list = <fun>  *)

let rec take n l = match l with
  | [] -> []
  | x::xs -> if n > 0 then x::take (n-1) xs else []

let rec drop n l = match l with
  | [] -> []
  | x::xs -> if n > 0 then drop (n-1) xs else l


let split_by f l1 l2 =
	let add (x,y) = x::y
	in
	rev (add (List.fold_left (fun (v1,v2) x -> if (is_elem_by f x l2) then ([],v1::v2) else (v1@[x],v2)) ([],[]) l1))

(* val split_by : ('a -> 'b -> bool) -> 'b list -> 'a list -> 'b list list = <fun> *)
(* Tuples in particular seem useful here, since it'll allow me to keep track of two things at a time fairly easily, the sublist I am building, and the part of the list I haven't checked yet. *)

(* Some functions for reading files. *)
let read_file (filename:string) : char list option =
  let rec read_chars channel sofar =
    try
      let ch = input_char channel
      in read_chars channel (ch :: sofar)
    with
    | _ -> sofar
  in
  try
    let channel = open_in filename
    in
    let chars_in_reverse = read_chars channel []
    in Some (rev chars_in_reverse)
  with
    _ -> None

type word = char list
type line = word list


let convert_to_non_blank_lines_of_words l =
  let helper1 l = split_by (=) l ['\n'] in
  let helper2 l = split_by (=) l [' ';',';'.';'!';';';':';'-'] in
  let filter l = List.filter (fun x-> x<>[]) l in
  let locase l = List.map Char.lowercase l in
filter (List.map filter (List.map helper2 (helper1 (locase l))))

type result = OK
	    | FileNotFound of string
	    | IncorrectNumLines of int
	    | IncorrectLines of (int * int) list
	    | IncorrectLastStanza


let trans l = match l with
    | Some l -> convert_to_non_blank_lines_of_words (l)
    | _ -> raise(Failure"FileNotFound")



let com12 s =
  if(take 1 s = (drop 1 (take 2 s))=false) then [(1,2)] else []
let com34 s =
  if((drop 2 (take 3 s))= (drop 3 (take 4 s))=false) then [(3,4)] else []
let com78 s =
  if((drop 6 (take 7 s))= (drop 7 (take 8 s))=false) then [(7,8)] else []
let com910 s =
  if((drop 8 (take 9 s))= (drop 9 (take 10 s))=false) then [(9,10)] else []
let com1314 s =
  if((drop 12 (take 13 s))= (drop 13 (take 14 s))=false) then [(13,14)] else []
let com1516 s =
  if((drop 14 (take 15 s))= (drop 15 (take 16 s))=false) then [(15,16)] else []

let com1356 s =
    if ((List.sort compare (List.concat((take 1 s)@(drop 2 (take 3 s))))) = (List.sort compare (List.concat((drop 4 (take 5 s))@(drop 5 (take 6 s))))) = false) then [(5,6)] else []

let com791112 s =
 if ((List.sort compare (List.concat((drop 6 (take 7 s))@(drop 8 (take 9 s))))) = (List.sort compare (List.concat((drop 10 (take 11 s))@(drop 11 (take 12 s))))) = false)  then [(11,12)] else []

 let com13151718 s =
  if ((List.sort compare (List.concat((drop 12 (take 13 s))@(drop 14 (take 15 s))))) = (List.sort compare (List.concat((drop 16 (take 17 s))@(drop 17 (take 18 s))))) = false)  then [(17,18)] else []

 let test1 s = if  ((com12 s)@(com34 s)) <> [] then (com12 s)@(com34 s) else com1356 s

 let test2 s = if ((com78 s)@(com910 s)) <> [] then (com78 s)@(com910 s) else com791112 s

 let test3 s = if ((com1314 s)@(com1516 s)) <> [] then (com1314 s)@(com1516 s) else com13151718 s

 let comsum s = (test1 s)@(test2 s)@(test3 s)

  let complast3 s =List.sort compare (dedup (List.concat (take 18 s))) = List.sort compare (dedup (List.concat (drop 18 s)))


let paradelle (filename:string):result =
let name = read_file filename in
if name = None then FileNotFound (filename)
else let l = trans name in
 match l with
    | l when (length l <> 24) -> IncorrectNumLines (length l)
    | l when (comsum l <> []) -> IncorrectLines (comsum l)
    | l when (complast3 l = false) -> IncorrectLastStanza
    | l   ->  OK
