### Hwk_03 score

Below are your scores for Hwk 03

If these scores are different from what you expect, please see the concerned TA to ensure the potential error is fixed.

Run on March 28, 13:04:07 PM.

+ _8_ /  _10_ :  Problem 1. Grader :  _Charles Harper_ 

		Comments : Incorrect use of multiplication on power (-2)



+ _10_ /  _10_ :  Problem 2. Grader :  _William Muesing_ 

		Comments : 



+ _9_ /  _10_ :  Problem 3. Grader :  _Chris Bradshaw_ 

		Comments : Incorrect inductive piece of principle of induction -1



+ _10_ /  _10_ :  Problem 4. Grader :  _Nick Krantz_ 

		Comments : 



+ _10_ /  _10_ :  Problem 5. Grader :  _Cosmos Zhu_ 

		Comments : 



+ _4_ /  _10_ :  Problem 6. Grader :  _Parag_ 

		Comments : How is sorted ([h1] @ place e (h2::t)) = true for case e >= h1? how are e and h2 related? Missing steps as well, you have reference and write each and every property of sorted and place used.



+ _5_ /  _10_ :  Problem 7. Grader :  _Shannyn_ 

		Comments : -5, sorted l is necessary for question 6 as place only ensures e is placed in l with larger values preceding it



+ Total: _56_ / _70_ 



