(*PART 1------------------------------------------------------------------------------------------*)
type expr
  = Const of int
  | Add of  expr * expr
  | Mul of expr * expr
  | Sub of expr * expr
  | Div of expr * expr

let rec show_expr = function
    | Const i -> string_of_int i
    | Add (e1,e2) -> "(" ^ show_expr e1 ^ "+" ^ show_expr e2 ^ ")"
    | Sub (e1,e2) -> "(" ^ show_expr e1 ^ "-" ^ show_expr e2 ^ ")"
    | Mul (e1,e2) -> "(" ^ show_expr e1 ^ "*" ^ show_expr e2 ^ ")"
    | Div (e1,e2) -> "(" ^ show_expr e1 ^ "/" ^ show_expr e2 ^ ")"

(*I use 0,1,2,3 to distinct the level of operator.
Such as we need to keep the original order of calculation.
Thus I put the latter parenthesis which located at inner expr +1.
When current level is greater than the operater's value, we have to add "()" to keep it working. *)
let rec former curr operator =
   if curr > operator then "(" else ""

let rec latter curr operator =
   if curr > operator then ")" else ""

let rec main_print curr expr =
    match expr with
    | Const i -> string_of_int i
    | Add (e1,e2) -> former curr 0 ^ main_print 0 e1 ^ "+" ^ main_print 1 e2 ^ latter curr 0
    | Sub (e1,e2) -> former curr 0 ^ main_print 0 e1 ^ "-" ^ main_print 1 e2 ^ latter curr 0
    | Mul (e1,e2) -> former curr 2 ^ main_print 2 e1 ^ "*" ^ main_print 3 e2 ^ latter curr 2
    | Div (e1,e2) -> former curr 2 ^ main_print 2 e1 ^ "/" ^ main_print 3 e2 ^ latter curr 2

let rec show_pretty_expr expr =
    main_print 0 expr


