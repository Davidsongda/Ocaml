type expr
  = Add of expr * expr
  | Sub of expr * expr
  | Mul of expr * expr
  | Div of expr * expr

  | Lt of expr * expr
  | Eq of expr * expr
  | And of expr * expr

  | If of expr * expr * expr

  | Id of string

  | Let of string * expr * expr
  | LetRec of string * expr * expr

  | App of expr * expr
  | Lambda of string * expr

  | Value of value

and value
  = Int of int
  | Bool of bool
  | Ref of value ref
  | Closure of string * expr * environment
  and environment = (string * value) list
  (* You may need an extra constructor for this type. *)

let rec freevars (e:expr) : string list =
  match e with
  | Value v -> []
  | Add (e1, e2) -> freevars e1 @
                    freevars e2
  | Sub (e1, e2) -> freevars e1 @
                    freevars e2
  | Mul (e1, e2) -> freevars e1 @
                    freevars e2
  | Div (e1, e2) -> freevars e1 @
                    freevars e2
  | App (f, a) -> freevars f @
                  freevars a
  | And (e1,e2) -> freevars e1 @ freevars e2

  | Eq (l,body) -> freevars body

  | If (e1,e2,e3) -> freevars e1 @
                     freevars e2 @
                     freevars e3
  | Lt (e1,e2) -> freevars e1 @
                  freevars e2
  | Lambda (i, body) ->
     List.filter
      (fun fv -> fv <> i)
      (freevars body)
  | Id i -> [i]
  | Let (i, dexpr, body) ->
    freevars dexpr @
    List.filter
      (fun fv -> fv <> i)
      (freevars body)
  | LetRec (i, f, l) -> List.filter
                          (fun fv -> fv <> i)
                          (freevars l)

  let rec lookup (n:string) (env:environment) :value =
    match env with
    | [] -> raise (Failure ("Identifier " ^ n ^ " is not in scope."))
    | (x,value)::rest when x = n -> value
    | _::rest -> lookup n rest

let rec eval (env: environment) (e: expr) : value =
  match e with
  | Value v -> v
  | Add (e1, e2) ->
     ( match eval env e1,eval env e2 with
       | Int i1, Int i2 -> Int (i1 + i2)
       | _ -> raise (Failure "Incompatible types on Add")
     )
  | Sub (e1, e2) ->
     ( match eval env e1, eval env e2 with
       | Int i1, Int i2 -> Int (i1 - i2)
       | _ -> raise (Failure "Incompatible types on Sub")
     )
  | Mul (e1, e2) ->
     ( match eval env e1,eval env e2 with
       | Int i1, Int i2 -> Int (i1 * i2)
       | _ -> raise (Failure "Incompatible types on Mul")
        )
  | Div (e1, e2) ->
     ( match eval env e1,eval env e2 with
       | Int i1, Int i2 -> Int (i1 / i2)
       | _ -> raise (Failure "Incompatible types on Div")
        )
  | Eq (e1, e2) ->
     ( match eval env e1,eval env e2 with
       | Int i1, Int i2 -> Bool (i1 = i2)
       | _ -> raise (Failure "Incompatible types on Eq")
        )
  | And (e1,e2) ->
     ( match eval env e1, eval env e2 with
        | Bool i1, Bool i2 -> Bool (i1 && i2)
        | _ -> raise (Failure "Incompatible types on And")
      )
  | Lt (e1, e2) ->
     ( match eval env e1, eval env e2 with
       | Int i1, Int i2 -> Bool (i1 < i2)
       | _ -> raise (Failure "Incompatible types on Lt")
     )
  | Id (e) -> lookup e env

  | If (e1, e2, e3) ->
     ( match eval env e1 with
       | Bool true -> eval env e2
       | Bool false -> eval env e3
       | _ -> raise (Failure "Incompatible types on If")
     )
  | Lambda (i,body) -> Closure (i,body,env)


  | App (f,a) -> (match eval env f with
                  | Closure (i,body,env2)  -> eval ((i, (eval env a))::env2) body
                  | Ref e -> (match (! e) with
                             | Closure (e,body,env3) -> eval ((e, (eval env a))::env3) body)
                  | _ -> raise (Failure "Incompatible types on App")
                  )
  | Let (i, dexpr, body) -> let dexpr_l = eval env dexpr in
                            let body_l = eval ((i,(dexpr_l))::env) body in
                            body_l

  | LetRec (i, dexpr, l) ->
                        match dexpr with
                        | Lambda (n,body) ->  let recRef = ref (Int 999) in
                        let c = Closure (n, body, (i,Ref recRef)::env) in
                        let () = recRef := c in
                        let l_v = eval ((i,c)::env) l in
                        l_v

  let rec evaluate (e: expr) : value = eval [] (e: expr)




(* Some sample expressions *)

let inc = Lambda ("n", Add(Id "n", Value (Int 1)))

let add = Lambda ("x",
                  Lambda ("y", Add (Id "x", Id "y"))
                 )

(* The 'sumToN' function *)
let sumToN_expr : expr =
    LetRec ("sumToN",
            Lambda ("n",
                    If (Eq (Id "n", Value (Int 0)),
                        Value (Int 0),
                        Add (Id "n",
                             App (Id "sumToN",
                                  Sub (Id "n", Value (Int 1))
                                 )
                            )
                       )
                   ),
            Id "sumToN"
           )


let twenty_one : value = evaluate (App (sumToN_expr, Value (Int 6)))
