type 'a stream = Cons of 'a * (unit -> 'a stream)

let head (s: 'a stream) : 'a = match s with
  | Cons (v, _) -> v

let tail (s: 'a stream) : 'a stream = match s with
  | Cons (_, tl) -> tl ()

let rec from n =
  Cons ( n,
         fun () -> print_endline ("step " ^ string_of_int (n+1)) ;
                   from (n+1) )

let rec take (n:int) (s : 'a stream) : ('a list) =
 if n = 0 then []
 else match s with
      | Cons (v, tl) -> v :: take (n-1) (tl ())


let rec squares_from n : int stream = Cons (n*n, fun () -> squares_from (n+1) )

let squares = squares_from 1

let rec ands (l:bool list): bool =
    match l with
    | [] -> true
    | x::xs -> if x = false then false else ands xs

let rec cubes_from x =
    Cons (x*x*x, fun () -> cubes_from (x+1))

let rec drop (x:int) (s:'a stream) : 'a stream =
    match s with
    | Cons (hd,tl) when hd = x -> drop x (tl())
    | Cons (hd,tl) -> Cons (hd, fun () -> drop x (tl()))


let rec drop_until (f: 'a -> bool) (s: 'a stream) : 'a stream =
  match s with
  | Cons (hd, tl) ->
     let rest = (fun () -> drop_until f (tl ()))
     in
     if f hd then Cons (hd, rest) else rest ()

let rec map (f: 'a -> 'b) (s: 'a stream) : 'b stream =
    match s with
    | Cons (hd,tl) ->
        let rest = (fun () -> map f (tl ()))
     in
     Cons (f hd , rest)

let squares_again (s: 'a stream) = map (fun x -> x*x) s

let rec sqrt_approximations n =
    let rec help up low =
        let g = (low +. up)/. 2.0 in
         if g*.g >n then Cons (g, fun () -> help g low)
                    else Cons (g, fun () -> help up g)
    in help n 1.0

let rec epsilon_diff x s =
    match s with
    | Cons (hd1,tl) ->
        match tl() with
        | Cons (hd2,tl2) -> if ((hd1-.hd2) < x && (hd1-.hd2) > 0.0) then hd2
                            else if ((hd2 -. hd1) >0.0 && (hd1-.hd2) < x) then hd1
                            else epsilon_diff x (tl())

let diminishing = let rec helper x = Cons (x, fun () -> helper (x/.2.0)) in helper 16.0


let rec sqrt_threshold v t =
    let rec helper s =
      (let temp = head s in
        if (abs_float((temp*.temp)-.v)<t) then temp
        else helper (tail s))
    in helper (sqrt_approximations v)
