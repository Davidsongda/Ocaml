type formula = And of formula * formula
	     | Or  of formula * formula
	     | Not of formula
	     | Prop of string
	     | True
	     | False

exception KeepLooking

type subst = (string * bool) list

let show_list show l =
  let rec sl l =
    match l with
    | [] -> ""
    | [x] -> show x
    | x::xs -> show x ^ "; " ^ sl xs
  in "[ " ^ sl l ^ " ]"

let show_string_bool_pair (s,b) =
  "(\"" ^ s ^ "\"," ^ (if b then "true" else "false") ^ ")"

let show_subst = show_list show_string_bool_pair

let is_elem v l =
  List.fold_right (fun x in_rest -> if x = v then true else in_rest) l false

let rec explode = function
  | "" -> []
  | s  -> String.get s 0 :: explode (String.sub s 1 ((String.length s) - 1))

let dedup lst =
  let f elem to_keep =
    if is_elem elem to_keep then to_keep else elem::to_keep
  in List.fold_right f lst []

let rec lookup (s:string) (sb: subst) :bool =
  match sb with
  | [] -> raise (Failure ("Identifier " ^ s ^ " is not in scope."))
  | (x,bool)::rest when x = s -> bool
  | _::rest -> lookup s rest


(*------------------------------------------------------------------------------------*)
let rec eval (f:formula) (sb: subst) : bool =
  match f with
  | Prop x -> lookup x sb
  | And (f1,f2) -> (eval f1 sb) && (eval f2 sb)
  | Or (f1,f2) -> (eval f1 sb) || (eval f2 sb)
	| Not (f) -> if (eval f sb) then false else true
	| True -> true
	| False -> false

let rec freevars (f:formula) : string list =
  match f with
	| And (f1,f2) -> dedup (freevars f1 @ freevars f2)
	| Or (f1,f2) -> dedup (freevars f1 @ freevars f2)
  | Not f -> dedup (freevars f)
	| Prop x -> [x]
  | True -> []
	| False -> []

(*---------------------------------------------------------------------------------------*)
let rec process_solution_v1 show sb =
  print_endline ("Here is a solution: \n" ^ show_subst sb) ;
  print_endline ("Do you like it?");

  match is_elem 'Y' (explode (String.capitalize (read_line ()))) with
  | true  -> print_endline "Thanks for playing..." ; Some sb
  | false -> raise KeepLooking

let is_tautology (f:formula) (process_solution_v1: subst->subst option) :subst option =
 let rec try_tauto f partial_subst rest_of_the_set =
  if partial_subst <> [] && rest_of_the_set = [] && (eval f partial_subst = false)
	then process_solution_v1 partial_subst
	else match rest_of_the_set with
	| [] -> None
	| x::xs -> try try_tauto f (partial_subst @ [(x,false)]) xs with
	           | KeepLooking -> try_tauto f (partial_subst @ [(x,true)]) xs
 in try_tauto f [] (freevars f)



let is_tautology_first f = is_tautology f (fun s -> Some s)

let is_tautology_print_all f =
  is_tautology
    f
    (fun s -> print_endline (show_subst s);
	      raise KeepLooking)
(*---------------------------------------------------------------------------------------*)






				exception KeepLooking

				let rec explode = function
				  | "" -> []
				  | s  -> String.get s 0 :: explode (String.sub s 1 ((String.length s) - 1))


				let rec maze_moves p =
				  match p with
					| (1,1) -> [(2,1)]
					| (2,1) -> [(3,1)]
					| (3,1) -> [(3,2)]
					| (4,1) -> [(4,2)]
					| (5,1) -> [(5,2)]
					| (1,2) -> [(1,3);(2,2)]
					| (2,2) -> [(3,2)]
					| (3,2) -> [(3,1);(3,3)]
				  | (4,2) -> [(4,1)]
					| (5,2) -> [(5,1);(5,3)]
					| (1,3) -> [(1,2);(1,4);(2,3)]
					| (2,3) -> [(1,3)]
					| (3,3) -> [(3,2);(3,4);(4,3)]
					| (4,3) -> [(3,3);(5,3)]
				  | (5,3) -> [(5,2);(5,4)]
				  | (1,4) -> [(1,3);(1,5)]
				  | (2,4) -> [(2,5);(3,4)]
				  | (3,4) -> [(2,4);(3,3);(4,4)]
				  | (4,4) -> [(3,4);(4,5)]
				  | (5,4) -> [(5,3)]
				  | (1,5) -> [(1,4);(2,5)]
				  | (2,5) -> [(2,4);(1,5)]
				  | (3,5) -> [(4,5)]
				  | (4,5) -> [(4,4);(3,5);(5,5)]
				  | (5,5) -> [(4,5)]
				  | (_,_) -> raise (Failure("We cannot reach that point"))

				let is_elem v l =
				  List.fold_right (fun x in_rest -> if x = v then true else in_rest) l false

				let rec is_not_elem set v =
				  match set with
				  | [] -> true
				  | s::ss -> if s = v then false else is_not_elem ss v

				let rec process_solution_exn show s =
				  Some s

				let show_list show l =
				  let rec sl l =
				    match l with
				    | [] -> ""
				    | [x] -> show x
				    | x::xs -> show x ^ "; " ^ sl xs
				  in "[ " ^ sl l ^ " ]"

				let show_loc x =  string_of_int x

				let show_position (x,y) =
				  "(" ^ show_loc x ^ ", " ^ show_loc y ^ ")"

				let show_path = show_list show_position


				let rec maze () =
				  let rec go_from position path =
				    if ( position = (5,1) || position = (3,5) )
				    then process_solution_exn show_path path
				    else
				      match List.filter (is_not_elem path) (maze_moves position) with
				      | [] -> raise KeepLooking
				      | [(x,y)] -> go_from (x,y) (path @ [(x,y)])
				      | [(x1,y1);(x2,y2)] ->
				                          (try (go_from (x1,y1) (path @ [(x1,y1)])) with
				                          | KeepLooking -> go_from (x2,y2) (path @ [(x2,y2)])
				                          )
				      | [(x1,y1);(x2,y2);(x3,y3)] ->
				                                 (try (go_from (x1,y1) (path @ [(x1,y1)])) with
				                                 | KeepLooking -> (try (go_from (x2,y2) (path @ [(x2,y2)])) with
				                                            | KeepLooking -> go_from (x3,y3) (path @ [(x3,y3)])
				                                            )
				                                 )
				     | _ -> raise (Failure ("No way to move to 4 points!"))
				   in try (go_from (2,3) [(2,3)]) with
				      | KeepLooking -> None
