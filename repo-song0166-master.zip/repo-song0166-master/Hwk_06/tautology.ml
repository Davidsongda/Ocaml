type formula = And of formula * formula
	     | Or  of formula * formula
	     | Not of formula
	     | Prop of string
	     | True
	     | False

exception KeepLooking

type subst = (string * bool) list

let show_list show l =
  let rec sl l =
    match l with
    | [] -> ""
    | [x] -> show x
    | x::xs -> show x ^ "; " ^ sl xs
  in "[ " ^ sl l ^ " ]"

let show_string_bool_pair (s,b) =
  "(\"" ^ s ^ "\"," ^ (if b then "true" else "false") ^ ")"

let show_subst = show_list show_string_bool_pair

let is_elem v l =
  List.fold_right (fun x in_rest -> if x = v then true else in_rest) l false

let rec explode = function
  | "" -> []
  | s  -> String.get s 0 :: explode (String.sub s 1 ((String.length s) - 1))

let dedup lst =
  let f elem to_keep =
    if is_elem elem to_keep then to_keep else elem::to_keep
  in List.fold_right f lst []

let rec lookup (s:string) (sb: subst) :bool =
  match sb with
  | [] -> raise (Failure ("Identifier " ^ s ^ " is not in scope."))
  | (x,bool)::rest when x = s -> bool
  | _::rest -> lookup s rest


(*------------------------------------------------------------------------------------*)
let rec eval (f:formula) (sb: subst) : bool =
  match f with
  | Prop x -> lookup x sb
  | And (f1,f2) -> (eval f1 sb) && (eval f2 sb)
  | Or (f1,f2) -> (eval f1 sb) || (eval f2 sb)
	| Not (f) -> if (eval f sb) then false else true
	| True -> true
	| False -> false

let rec freevars (f:formula) : string list =
  match f with
	| And (f1,f2) -> dedup (freevars f1 @ freevars f2)
	| Or (f1,f2) -> dedup (freevars f1 @ freevars f2)
  | Not f -> dedup (freevars f)
	| Prop x -> [x]
  | True -> []
	| False -> []

(*---------------------------------------------------------------------------------------*)
let rec process_solution_v1 show sb =
  print_endline ("Here is a solution: \n" ^ show_subst sb) ;
  print_endline ("Do you like it?");

  match is_elem 'Y' (explode (String.capitalize (read_line ()))) with
  | true  -> print_endline "Thanks for playing..." ; Some sb
  | false -> raise KeepLooking

let rec is_tautology f process_solution_v1 = 
  let rec helper partial_sb rest_of_sb = 
    if partial_sb <> [] && rest_of_sb = [] && (eval f partial_sb) = false
    then process_solution_v1 partial_sb 
    else 
    match rest_of_sb with
    | [] -> raise KeepLooking
    | x::xs -> try helper (partial_sb @ [(x,false)]) xs with 
               | KeepLooking -> helper (partial_sb @ [(x,true)]) xs
  in try helper [] (freevars f) with
     | KeepLooking -> None  (*try*)



let is_tautology_first f = is_tautology f (fun s -> Some s)

let is_tautology_print_all f =
  is_tautology
    f
    (fun s -> print_endline (show_subst s);
	      raise KeepLooking)
