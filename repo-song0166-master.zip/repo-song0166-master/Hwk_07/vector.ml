module type Operation = sig
  type t
  val add : t -> t -> t
  val mul : t -> t -> t
  val zero : t
  val to_string : t -> string
end

module type Arithmetic_intf = sig
  type t
  type v
  val create : int -> t -> v
  val from_list : t list -> v
  val to_list : v -> t list
  val scalar_add : t -> v -> v
  val scalar_mul : t -> v -> v
  val scalar_prod : v -> v -> t option
  val to_string : v -> string
  val size : v -> int
end


module Make_vector (Op : Operation) :
    (Arithmetic_intf with type t = Op.t) = struct
    
    
    
    
    type t = Op.t
    type v = Vector of (Op.t) list


let create (num:int) (x:Op.t) : v =
   let rec helper n y =
    if n = 0 then []
    else x :: helper (n-1) y
  in
  Vector (helper num x)

let from_list (l:t list) : v = Vector(l)

let to_list vec =
   match vec with
   | Vector v -> v
   | _ -> raise (Failure "error")

let rec scalar_add x v1 =
     let rec helper x vlist =
      (match vlist with
      | [] -> []
      | h::t -> (Op.add x h) :: (helper x t))
     in Vector (helper x (to_list v1))


let scalar_mul x v1 =
   let rec helper x vlist =
    (match vlist with
     | [] -> []
     | h::t -> (Op.mul x h) :: helper x t)
   in Vector (helper x (to_list v1))


let size (vec:v) : int =
   let rec helper v =
     match v with
     | h::t -> 1 + helper t
     | [] -> 0
     in
   helper (to_list vec)



let scalar_prod v1 v2  =
  (match v1,v2 with
  | Vector a, Vector b ->
  let rec helper x y =
    (match x,y with
    | (h1::t1),(h2::t2) -> Op.add (Op.mul h1 h2) (helper t1 t2)
    | [],[] -> Op.zero
    | _ -> raise (Failure "error"))
  in
  if size v1 = size v2
    then Some (helper a b)
    else None
  | _ -> raise (Failure "type error"))



let rec to_string (vec:v) : string =
"<<" ^ " " ^ string_of_int(size vec) ^ " " ^ "|" ^ " " ^ String.concat "," (List.map Op.to_string (to_list vec)) ^ " " ^ ">>"


end
