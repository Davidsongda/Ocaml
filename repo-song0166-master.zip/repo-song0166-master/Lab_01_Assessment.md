### Assessment for Lab 01

#### Total score: _25_ / _25_

Run on February 10, 11:13:36 AM.

+ Pass: Change into directory "Lab_01".

+ Pass: Check that file "fib.ml" exists.

+  _5_ / _5_ : Pass: Check that an OCaml file "fib.ml" has no syntax or type errors.

    OCaml file "fib.ml" has no syntax or type errors.



+  _10_ / _10_ : Pass: Check that the result of evaluating `fib 0` matches the pattern `0`.

   



+  _10_ / _10_ : Pass: Check that the result of evaluating `fib 5` matches the pattern `5`.

   



#### Total score: _25_ / _25_

