### Feedback for Lab 01

Run on May 09, 14:16:35 PM.

+ Pass: Change into directory "Lab_01".

+ Pass: Check that file "fib.ml" exists.

+ Pass: Check that an OCaml file "fib.ml" has no syntax or type errors.

    OCaml file "fib.ml" has no syntax or type errors.



+ Pass: 
Check that the result of evaluating
   ```
   fib 0
   ```
   matches the pattern `0`.

   




+ Pass: 
Check that the result of evaluating
   ```
   fib 5
   ```
   matches the pattern `5`.

   




