let circle_area_v1 diameter = 0.5*.diameter*.0.5*.diameter*.3.1415;;

let circle_area_v2 diameter = 
let pi = 3.1415 in 
let divide d = 0.5*.d in
let square r = r*.r in
square (divide diameter) *.pi;;

let rec product list =
match list with
| []->1
| h::t->h*product t;;

let rec sum_diffs list = 
match list with
| x1::(x2::[])->x1-x2
| x1::x2::t->x1 - x2 + sum_diffs (x2::t);;


let distance (a1,b1) (a2,b2) = 
sqrt((a1-.a2)*.(a1-.a2)+.(b1-.b2)*.(b1-.b2));;
 

let triangle_perimeter (x1,y1) (x2,y2) (x3,y3) = 
distance (x1,y1) (x2,y2) +. distance (x1,y1) (x3,y3) +. distance (x3,y3) (x2,y2);;

