(*MY NAME: DA SONG GROUP MEMBERS: YONGLE ZHANG, Kejing Li*)

let even x =

 if x mod 2=0 then true

 else false;;





let rec euclid x y =

if x=y then x

else if x<y then (euclid x (y-x))

else (euclid(x-y) y);;



let frac_add (n1,d1) (n2,d2) = (n1*d2+n2*d1, d1*d2);;





let frac_simplify(a,b) = (a/euclid a b,b/euclid a b);;





let square_approx n acc =

let divide n m = (n+.m)/.2.0

in
let rec helper (low,up) =

if up-.low>acc

then if (divide low up)*.(divide low up)>n

        then helper ( low,divide low up)

        else helper (divide low up, up)

else (low,up)

in helper (1.0,n);;





let rec max_list list =

match list with

| []->raise (Failure "not empty lists allowed")
| x1::[]->x1  (*I did not write this line in the Hwk_01. This case(ONLY HAVE ONE SUBLIST IN THE WHOLE LIST) must be discussed to avoid the warning. --From YONGLE *)

| x1::x2::[]->if x1>x2 then x1 else x2

| x1::x2::t-> if x1>x2 then max_list (x1::t) else max_list(x2::t);;





let rec drop x list =

match list with

| []->[]

| h::t->let drop_list = drop (x-1) t in

        if x=0 then h::t

	else drop_list;;





  let rec rev list =

  match list with

  | []->[]

  |x1::t->if t =[] then (x1::[])
		else  (rev t@( x1::[]));;





  let perimeter list =

  match list with
  |[]->raise (Failure "not empty lists allowed")  (*I did not write this line in the Hwk_01. This case(empty list) must be discussed to avoid the empty list case. --From KEJING*)
  |h::t->

  let rec distance (a1,b1) (a2,b2) = sqrt((a1-.a2)*.(a1-.a2)+.(b1-.b2)*.(b1-.b2))

  in

  let rec helper peri head l =

  match l with

  | []->raise (Failure "not empty lists allowed")
  | x1::[]->0.0  (*I did not write this line in the Hwk_01. This case(ONlY HAVE ONE POINT) must be discussed to avoid the case which the list only have one point.--From KEJING*)

  | x1::x2::t-> if t=[] then peri+.(distance x1 x2) +. (distance x2 head)

			else (helper (peri+.(distance x1 x2)) head (x2::t))

  in

  helper 0.0 h list;;



let rec is_matrix list =

let rec length lst =

  match lst with

  | [] -> 0

  | h::t -> 1 + length t

in

match list with

| []->false

| [x1]->true

| x1::x2::[]->if length x1 = length x2 then true else false

| x1::x2::t-> is_matrix t;;





let rec matrix_scalar_add list n =

let rec helper l n =

match l with

| []->[]

| h::t-> if t = [] then ((h+n)::[]) else ((h+n) :: helper t n)

in

match list with

| []->[]
| h::t->if t=[] then ((helper h n)::[])
        else  ((helper h n)::(matrix_scalar_add t n))
         (*I did not write the if-else sentence in the Hwk_01. This case(t=[]) must be discussed to avoid the list only have one element which is 'h'.--From YOONGLE*)
