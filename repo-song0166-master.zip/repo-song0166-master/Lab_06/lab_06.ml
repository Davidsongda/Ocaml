type 'a tree = Leaf of 'a
             | Fork of 'a * 'a tree * 'a tree
(*Def of tree*)

(*PART 1-------------------------------------------------------------------*)

    let t_1 = Leaf 5
    let t_2 = Fork (3, Leaf 3, Fork (2, t_1, t_1))
    let t_3 = Fork ("Hello", Leaf "World", Leaf "!")
    let t4 = Fork (7, Fork (5, Leaf 1, Leaf 2), Fork (6, Leaf 3, Leaf 4))

(*Examples*)

let rec t_size t =
  match t with
  | Leaf _ -> 1
  | Fork (_, t1, t2) -> 1 + t_size t1 + t_size t2


let rec t_sum t =
  match t with
  | Leaf v -> v
  | Fork (v, t1, t2) -> v + t_sum t1 + t_sum t2

let rec t_charcount t =
    match t with
    | Leaf v -> String.length v
    | Fork (v, t1, t2) -> String.length v + t_charcount t1 + t_charcount t2

let rec t_concat t =
  match t with
  | Leaf v -> v^""
  | Fork (v, t1, t2) -> v^""^ t_concat t1 ^ t_concat t2


(*PART 2-----------------------------------------------------------------------*)

   let t5 : string option tree =
   Fork (Some "a", Leaf (Some "b"), Fork (Some "c", Leaf None, Leaf (Some "d")))

   let t7 = (Fork (Some 1, Leaf (Some 2), Fork (Some 3, Leaf None, Leaf None)))

   let t8 = (Fork (Some "a", Leaf (Some "b"), Fork (Some "c", Leaf None, Leaf (Some "d"))))



let rec t_opt_size t =
  match t with
  | Leaf Some v -> 1
  | Leaf None -> 0
  | Fork (Some v, t1, t2) -> 1 + t_opt_size t1 + t_opt_size t2
  | Fork (None, t1, t2) -> 0 + t_opt_size t1 + t_opt_size t2

let rec t_opt_sum t =
  match t with
  | Leaf Some v -> v
  | Leaf None -> 0
  | Fork (Some v, t1, t2) -> v + t_opt_sum t1 + t_opt_sum t2
  | Fork (None, t1, t2) -> 0 + t_opt_sum t1 + t_opt_sum t2

let rec t_opt_charcount t =
  match t with
  | Leaf Some v -> String.length v
  | Leaf None -> 0
  | Fork (Some v, t1, t2) -> String.length v + t_opt_charcount t1 + t_opt_charcount t2
  | Fork (None, t1, t2) -> 0 + t_opt_charcount t1 + t_opt_charcount t2

let rec t_opt_concat t =
  match t with
  | Leaf Some v -> v ^ ""
  | Leaf None -> ""
  | Fork (Some v, t1, t2) -> v^"" ^ t_opt_concat t1 ^ t_opt_concat t2
  | Fork (None, t1, t2) -> "" ^ t_opt_concat t1 ^ t_opt_concat t2

(*PART 3-------------------------------------------------------------------------------*)

let rec tfold (l:'a -> 'b) (f:'a -> 'b -> 'b -> 'b)  (t:'a tree) : 'b =
    match t with
    | Leaf v -> l v
    | Fork (v, t1, t2) -> f v (tfold l f t1) (tfold l f t2)


let tf_size t = tfold (fun x->1) (fun x y z -> 1 + y + z) t

let tf_sum t = tfold (fun x->x) (fun x y z -> x + y + z) t

let tf_char_count t = tfold (fun x-> (String.length x)) (fun x y z -> String.length x + y + z) t

let tf_concat t = tfold (fun x-> x^"") (fun x y z -> x ^ y ^ z) t

let tf_opt_size t =
  let f x =
    match x with
    | Some x -> 1
    | None -> 0
    in
    tfold f (fun x y z -> if (f x = 1) then 1 + y + z
                          else 0+y+z) t

let tf_opt_sum t =
  let f1 x =
    match x with
    | Some x -> x
    | None -> 0
    in tfold f1 (fun x y z -> (f1 x) + y + z) t

let tf_opt_char_count t =
    let f1 x =
      match x with
      | Some x -> String.length x
      | None -> 0
      in tfold f1 (fun x y z -> (f1 x) + y + z) t

let tf_opt_concat t =
    let f1 x =
      match x with
      | Some x -> x^""
      | None -> ""
      in tfold f1 (fun x y z -> (f1 x) ^ y ^ z) t


  (*PART 4-------------------------------------------------------------------------------------*)

  type 'a btree = Empty
              | Node of 'a btree * 'a * 'a btree

  let t6 = Node (Node (Empty, 3, Empty), 4, Node (Empty, 5, Empty))

let rec bt_insert_by f x t =
    match t with
    | Empty -> Node (Empty, x, Empty)
    | Node (a1, v, a2) -> if (f x v = -1) then Node (bt_insert_by f x a1 , v , a2)
                          else if (f x v = 1) then Node (a1, v , bt_insert_by f x a2)
                          else Node (bt_insert_by f x a1 , v , a2)

let rec bt_to_list t =
      match t with
      | Empty -> []
      | Node(a1,v,a2) -> (bt_to_list a1) @ [v] @ (bt_to_list a2)


let rec bt_elem_by f x t =
    match t with
    | Empty -> false
    | Node(a1,v,a2) -> if f v x then true else (bt_elem_by f x a1) || (bt_elem_by f x a2)

let rec btfold (l:'b) f t =
    match t with
    | Empty -> l
    | Node(a1,v,a2) -> f (btfold l f a1) v (btfold l f a2)


let btf_elem_by eq x t = btfold false (fun a1 v a2 -> a1||(eq v x)||a2) t

let btf_to_list t = btfold [] (fun a1 v a2 -> a1 @ [v] @ a2) t

(*
let btf_insert_by x f t =
btfold Node (Empty, x , Empty) (fun a1 v a2 -> if (v>x) then f a1
                                          else if (v<x) then f a2
                                          else f v) t
*)


(*The above code is my attempt to write the btf_insert_by function. The Error is The constructor Node expects 3 argument(s),
       but is applied here to 0 argument(s). Thus the difficult point may be how to set the Node's argument.
*)
