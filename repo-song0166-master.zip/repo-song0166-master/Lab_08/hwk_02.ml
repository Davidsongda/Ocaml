(*I don't have any warnings, clumsy list constructions and ";;" in my file*)

(* This file contains a few helper functions and type declarations
   that are to be used in Homework 2. *)

(* Place part 1 functions 'take', 'drop', 'length', 'rev',
   'is_elem_by', 'is_elem', 'dedup', and 'split_by' here. *)

let length l = List.fold_left (fun n x -> n+1) 0 l
(* val length : 'a list -> int = <fun>  *)

let rev lst = List.fold_left (fun x xs -> xs::x) [] lst            
(* val rev : 'a list -> 'a list = <fun> *)

let is_elem_by equals e lst = if (List.filter (fun x -> equals x e) lst) = [] then false
                              else true
(* val is_elem_by : ('a -> 'b -> bool) -> 'b -> 'a list -> bool = <fun> *)

let is_elem e lst = is_elem_by (fun x y -> x = y) e lst
(* val is_elem : 'a -> 'a list -> bool = <fun> *)

let dedup lst =
    List.fold_right (fun x l -> if(is_elem x l = true) then l
    else x::l)  lst []
(* val dedup : 'a list -> 'a list = <fun>  *)

let rec take n l = match l with
  | [] -> []
  | x::xs -> if n > 0 then x::take (n-1) xs else []

let rec drop n l = match l with
  | [] -> []
  | x::xs -> if n > 0 then 
               drop (n-1) xs 
             else 
               l                     (*The previous one has wrong format, Dong Liang helps me changes it to right format*)


let split_by f l1 l2 =
	let add (x,y) = x::y
	in
	rev (add (List.fold_left (fun (v1,v2) x -> if (is_elem_by f x l2) then ([],v1::v2) else (v1@[x],v2)) ([],[]) l1)) 



(* Some functions for reading files. *)
let read_file (filename:string) : char list option =
  let rec read_chars channel sofar =
    try
      let ch = input_char channel
      in read_chars channel (ch :: sofar)
    with
    | _ -> sofar
  in
  try
    let channel = open_in filename
    in
    let chars_in_reverse = read_chars channel []
    in Some (rev chars_in_reverse)
  with
    _ -> None

type word = char list
type line = word list


let convert_to_non_blank_lines_of_words l =
  let helper1 l = split_by (=) l ['\n'] in
  let helper2 l = split_by (=) l [' ';',';'.';'!';';';':';'-'] in
  let filter l = List.filter (fun x-> x<>[]) l in
  let locase l = List.map Char.lowercase l in
filter (List.map filter (List.map helper2 (helper1 (locase l))))
(*In the convert_to_nonblank_lines_of_words function, Dong Liang and Song Liu have differnt solution from me. 
My solution is that I need to firstly remove the punctuations and then use filter to remove those blank lines.
The following content is their thought and code.
fun#2   convert_to_non_blank_lines_of_words: i changed the helper functions' name from erase_blank and 
	erase_blank2 to erase_single_emptylist and erase_double_emptylist and make it more readable and meaningful
	contributer: Song Liu

let erase_double_emptylist lst =
  List.filter (fun x -> x <> ([[]])) lst 

let erase_single_emptylist lst = 
  List.filter (fun x -> x <> ([])) lst 


let convert_to_non_blank_lines_of_words (l:char list) : line list =
	let helper_low l1 =
	List.map Char.lowercase l1
	in
	let helper1 l1 =
	split_by (=) l1 ['\n']
	in
	let helper2 l1 =
	split_by (=) l1 [' ';',';'!';'?';'-';';';'.';':']
	in
	erase_single_emptylist (List.map erase_single_emptylist (erase_double_emptylist (List.map helper2 (helper1 (helper_low l)))))*)

type result = OK
	    | FileNotFound of string
	    | IncorrectNumLines of int
	    | IncorrectLines of (int * int) list
	    | IncorrectLastStanza


let trans l = match l with
    | Some l -> convert_to_non_blank_lines_of_words (l)
    | _ -> raise(Failure"FileNotFound")



let com12 s =
  if(take 1 s = (drop 1 (take 2 s))=false) then 
    [(1,2)] 
  else 
    []      (*The previous one has wrong format, I changes it to right format by myself*)
let com34 s =
  if((drop 2 (take 3 s))= (drop 3 (take 4 s))=false) then 
    [(3,4)] 
  else 
    []      (*The previous one has wrong format, I changes it to right format by myself*)
let com78 s =
  if((drop 6 (take 7 s))= (drop 7 (take 8 s))=false) then 
    [(7,8)] 
  else 
    []       (*The previous one has wrong format, I changes it to right format by myself*)
let com910 s =
  if((drop 8 (take 9 s))= (drop 9 (take 10 s))=false) then 
     [(9,10)] 
  else 
     []      (*The previous one has wrong format, I changes it to right format by myself*)
let com1314 s =
  if((drop 12 (take 13 s))= (drop 13 (take 14 s))=false) then 
     [(13,14)] 
  else 
     []       (*The previous one has wrong format, I changes it to right format by myself*)
let com1516 s =
  if((drop 14 (take 15 s))= (drop 15 (take 16 s))=false) then 
     [(15,16)] 
  else 
     []       (*The previous one has wrong format, I changes it to right format by myself*)

let com1356 s =
    if ((List.sort compare (List.concat((take 1 s)@(drop 2 (take 3 s))))) = (List.sort compare (List.concat((drop 4 (take 5 s))@(drop 5 (take 6 s))))) = false) then 
      [(5,6)] 
    else 
      []            (*The previous one has wrong format, Song Liu helps me changes it to right format*)

let com791112 s =
 if ((List.sort compare (List.concat((drop 6 (take 7 s))@(drop 8 (take 9 s))))) = (List.sort compare (List.concat((drop 10 (take 11 s))@(drop 11 (take 12 s))))) = false)  then [(11,12)] else []

 let com13151718 s =
  if ((List.sort compare (List.concat((drop 12 (take 13 s))@(drop 14 (take 15 s))))) = (List.sort compare (List.concat((drop 16 (take 17 s))@(drop 17 (take 18 s))))) = false)  then [(17,18)] else []

 let test1 s = if  ((com12 s)@(com34 s)) <> [] then (com12 s)@(com34 s) else com1356 s

 let test2 s = if ((com78 s)@(com910 s)) <> [] then (com78 s)@(com910 s) else com791112 s

 let test3 s = if ((com1314 s)@(com1516 s)) <> [] then (com1314 s)@(com1516 s) else com13151718 s

 let comsum s = (test1 s)@(test2 s)@(test3 s)

  let complast3 s =List.sort compare (dedup (List.concat (take 18 s))) = List.sort compare (dedup (List.concat (drop 18 s)))


let paradelle (filename:string):result =
let name = read_file filename in
let l = trans name in
if name = None then FileNotFound (filename)
else match l with
    | l when (length l <> 24) -> IncorrectNumLines (length l)
    | l when (comsum l <> []) -> IncorrectLines (comsum l)
    | l when (complast3 l = false) -> IncorrectLastStanza
    | l   ->  OK
