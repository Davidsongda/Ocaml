type 'a stream = Cons of 'a * (unit -> 'a stream)

let head (s: 'a stream) : 'a = match s with
  | Cons (v, _) -> v

let tail (s: 'a stream) : 'a stream = match s with
  | Cons (_, tl) -> tl ()


let rec from n = 
  Cons ( n, 
         fun () -> print_endline ("step " ^ string_of_int (n+1)) ; 
                   from (n+1) )
let nats = from 1

let rec take (n:int) (s : 'a stream) : ('a list) =
 if n = 0 then []
 else match s with
      | Cons (v, tl) -> v :: take (n-1) (tl ())

let rec str_from n = 
  Cons ( string_of_int n, 
         fun () -> print_endline ("step " ^  string_of_int (n+1)) ; 
                   str_from  (n+1) )
                
let str_nats = str_from 1


let rec helper n sep a  =  
    if n = 0 then Cons ( "\n", fun () -> helper a sep a)
             else 
             Cons ( sep, 
                    fun () -> helper (n-1) sep a)
let separators n sep = helper n sep n

let ten_per_line = separators 9 ", "


let rec alternate a1 a2 = 
  match a1 with 
  | Cons (hd1,tl1) ->
      Cons ( hd1 , fun () -> match a2 with 
                             | Cons (hd2,tl2) -> Cons ( hd2 , fun () -> alternate (tl1()) (tl2())))

let str_105_nats = 
  List.fold_left (fun x y -> x ^ y) "" (take 209 (alternate str_nats ten_per_line))
  

