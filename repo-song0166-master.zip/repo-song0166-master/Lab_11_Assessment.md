### Assessment for Lab 11

#### Total score: _20_ / _20_

Run on April 10, 00:34:37 AM.

+ Pass: Change into directory "Lab_11".

+ Pass: Check that file "interpreter.ml" exists.

+ Pass: Check that an OCaml file "interpreter.ml" has no syntax or type errors.

    OCaml file "interpreter.ml" has no syntax or type errors.



+  _2_ / _2_ : Pass: Check that the result of evaluating `num_sums` matches the pattern `11`.

   



+  _2_ / _2_ : Pass: Check that the result of evaluating `val_sum_evens` matches the pattern `56`.

   



+  _2_ / _2_ : Pass: Check that the result of evaluating `val_sum_odds` matches the pattern `49`.

   



+  _2_ / _2_ : Pass: Check that the result of evaluating `num_sum_evens` matches the pattern `9`.

   



+  _2_ / _2_ : Pass: Check that the result of evaluating `num_sum_odds` matches the pattern `8`.

   



+  _5_ / _5_ : Pass: Check that the result of evaluating `lookup "sum_evens" (exec program_3_test [])` matches the pattern `Int 30`.

   



+  _5_ / _5_ : Pass: Check that the result of evaluating `lookup "y" (exec program_4 [("x",Int 4)])` matches the pattern `Int 6`.

   



