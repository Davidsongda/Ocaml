### Assessment for Lab 15

#### Total score: _15_ / _15_

Run on May 09, 14:54:54 PM.

+ Pass: Change into directory "Lab_15".

+ Pass: Check that file "src/translate.ml" exists.

+  _5_ / _5_ : Pass: Check that the result of executing build.sh on `examples/mapseq.src.txt` matches the pattern `Returned \[2, 4, 6, 8\]`.

   



+  _5_ / _5_ : Pass: Check that the result of executing build.sh on `examples/map.src.txt` matches the pattern `Returned \[2, 4, 6, 8\]`.

   



+  _5_ / _5_ : Pass: Check that the result of executing build.sh on `examples/fold.src.txt` matches the pattern `Returned 16`.

   



