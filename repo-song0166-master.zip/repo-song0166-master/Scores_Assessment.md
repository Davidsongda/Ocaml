### All scores

Below are your scores for the specified homework assignments and exams.

If these scores are different from what you expect AND a correction would likely change your letter grade then please contact Eric.

Please see the post on Moodle for description of these scores and their meanings.


Note that in adjusting the score of Problem 2 on Quiz 3 to be the higher of your actual score or your average quiz score, if your average quiz score was used then a number with several decimal places will be displayed.  This is the explanation for a non-interger score on your Quiz 3.


Run on May 15, 16:35:46 PM.

+ _52_ /  _75_ : Quiz 1

  Average score: 48.2

+ _52_ /  _70_ : Quiz 2

  Average score: 49.6

+ _46.68095238_ /  _70_ : Quiz 3

  Average score: 47.5

+ _44_ /  _55_ : Quiz 4

  Average score: 40.0

+ _85_ /  _105_ : Final

  Average score: 81.6

+ _100_ /  _100_ : Hwk 01

  Average score: 92.9

+ _71_ /  _71_ : Hwk 02

  Average score: 62.0

+ _56_ /  _70_ : Hwk 03

  Average score: 56.6

+ _100_ /  _100_ : Hwk 04

  Average score: 84.5

+ _124_ /  _135_ : Hwk 05

  Average score: 124.1

+ _17_ /  _17_ : Hwk 06

  Average score: 16.3

+ _44_ /  _45_ : Hwk 07

  Average score: 39.7

+ _25_ /  _25_ : Lab 01

  Average score: 24.4

+ _50_ /  _50_ : Lab 02

  Average score: 49.1

+ _184_ /  _184_ : Lab 03

  Average score: 169.3

+ _73_ /  _73_ : Lab 06

  Average score: 68.7

+ _108_ /  _109_ : Lab 08

  Average score: 95.8

+ _25_ /  _25_ : Lab 10

  Average score: 23.9

+ _20_ /  _20_ : Lab 11

  Average score: 19.5

+ _15_ /  _10_ : Lab 15

  Average score: 10.4

+ _85.54%_ /  _100%_ : Cummulative

  Average score: 76.1%

+ Letter grade: B+



